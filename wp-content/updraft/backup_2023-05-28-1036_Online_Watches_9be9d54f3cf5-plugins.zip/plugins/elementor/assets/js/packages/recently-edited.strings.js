/* translators: %s: Post type label. */
__('%s Settings', 'elementor');
__('Recent', 'elementor');
__('There are no other pages or templates on this site yet.', 'elementor');